--If you are using Windows or Linux, double click the
  appropriate LAUNCH_OS file.

--If you're using a Mac and know how to run Java or Class
  files, do what you can with the files I've supplied.
  If you don't know how to do this, I can't help you at
  the moment, sorry

--If you're a noob and don't understand the concept of
  creating a file and then opening it

  OR
  
  you don't want to go through the process of making a new
  file to play back using that feature, just type in the
  name of one of the midi sequences I've supplied in this
  folder and open that.

VERSION 2.0 NEW FEATURES:

--Graphical User Interface!  A nub one, but a GUI
  nonetheless

--A couple new instruments added, guitar sound changed

--A few aspects of the algorithm have changed.  Chords
  on piano, organ, and guitar are less often used and
  the probability weighting in terms of how the chord
  patterns are selected has shifted slightly

--A bug that continued to allow JazzerBot to select
  two-measure rests when it's JazzerBot's turn on
  trading fours has been resolved.  JazzerBot will now
  play for ALL FOUR MEASURES OF ITS TURN, EVERY TIME

